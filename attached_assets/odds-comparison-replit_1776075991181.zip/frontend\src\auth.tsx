import { createContext, useContext, useEffect, useState } from "react";

const API_BASE = "http://localhost:4000";

type AuthContextValue = {
  token: string | null;
  email: string | null;
  login: (email: string, password: string) => Promise<void>;
  register: (email: string, password: string) => Promise<void>;
  logout: () => void;
};

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [token, setToken] = useState<string | null>(null);
  const [email, setEmail] = useState<string | null>(null);

  useEffect(() => {
    const stored = window.localStorage.getItem("odds-auth");
    if (stored) {
      const parsed = JSON.parse(stored) as { token: string; email: string };
      setToken(parsed.token);
      setEmail(parsed.email);
    }
  }, []);

  const persist = (t: string | null, e: string | null) => {
    setToken(t);
    setEmail(e);
    if (t && e) {
      window.localStorage.setItem(
        "odds-auth",
        JSON.stringify({ token: t, email: e })
      );
    } else {
      window.localStorage.removeItem("odds-auth");
    }
  };

  const login = async (emailParam: string, password: string) => {
    const res = await fetch(`${API_BASE}/auth/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email: emailParam, password })
    });
    if (!res.ok) {
      throw new Error("Login failed");
    }
    const data = (await res.json()) as { token: string };
    persist(data.token, emailParam);
  };

  const register = async (emailParam: string, password: string) => {
    const res = await fetch(`${API_BASE}/auth/register`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email: emailParam, password })
    });
    if (!res.ok) {
      throw new Error("Register failed");
    }
    const data = (await res.json()) as { token: string };
    persist(data.token, emailParam);
  };

  const logout = () => {
    persist(null, null);
  };

  return (
    <AuthContext.Provider value={{ token, email, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}

export function authHeaders(token: string | null) {
  return token ? { Authorization: `Bearer ${token}` } : {};
}

