/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  darkMode: "class",
  theme: {
    extend: {
      colors: {
        surface: {
          DEFAULT: "#0b1020",
          raised: "#11172a"
        },
        accent: {
          DEFAULT: "#22d3ee",
          soft: "#0f172a"
        }
      }
    }
  },
  plugins: []
};

