export type OutcomeOdds = {
  outcome: string;
  value: number;
};

export type OddsRow = {
  match: string;
  bookmaker: string;
  odds: OutcomeOdds[];
};

export type OddsSource = {
  name: string;
  fetchOdds(): Promise<OddsRow[]>;
};

export type ComparedOutcome = {
  outcome: string;
  value: number;
  bookmaker: string;
};

export type ComparedRow = OddsRow & {
  bestOutcomes: ComparedOutcome[];
};
