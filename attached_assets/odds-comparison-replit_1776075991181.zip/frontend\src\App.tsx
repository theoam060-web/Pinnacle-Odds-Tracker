import { useEffect, useMemo, useState } from "react";

type OutcomeOdds = {
  outcome: string;
  value: number;
};

type ComparedOutcome = {
  outcome: string;
  value: number;
  bookmaker: string;
};

type ComparedRow = {
  match: string;
  bookmaker: string;
  odds: OutcomeOdds[];
  bestOutcomes: ComparedOutcome[];
};

function App() {
  const [rows, setRows] = useState<ComparedRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const load = async () => {
      setLoading(true);
      setError(null);
      try {
        const response = await fetch("/api/odds/best");
        if (!response.ok) {
          throw new Error("Could not load odds from backend.");
        }
        const payload = (await response.json()) as ComparedRow[];
        setRows(payload);
      } catch (err) {
        setError((err as Error).message);
      } finally {
        setLoading(false);
      }
    };

    void load();
  }, []);

  const groupedByMatch = useMemo(() => {
    const map = new Map<string, ComparedRow[]>();
    for (const row of rows) {
      const list = map.get(row.match) ?? [];
      list.push(row);
      map.set(row.match, list);
    }
    return [...map.entries()];
  }, [rows]);

  return (
    <main className="min-h-screen bg-slate-950 text-slate-100 p-4 md:p-8">
      <div className="max-w-6xl mx-auto space-y-6">
        <header className="space-y-2">
          <h1 className="text-2xl md:text-3xl font-semibold">
            Odds Comparison Prototype
          </h1>
          <p className="text-slate-400 text-sm">
            School project demo. Backend source can be swapped via environment
            settings.
          </p>
        </header>

        {loading && <p className="text-slate-400">Loading odds...</p>}
        {error && <p className="text-red-300">{error}</p>}

        {!loading &&
          !error &&
          groupedByMatch.map(([match, matchRows]) => (
            <section
              key={match}
              className="rounded-xl border border-slate-800 bg-slate-900/50 overflow-hidden"
            >
              <div className="px-4 py-3 border-b border-slate-800">
                <h2 className="font-medium">{match}</h2>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-slate-900 border-b border-slate-800 text-slate-300">
                      <th className="px-4 py-2 text-left">Bookmaker</th>
                      <th className="px-4 py-2 text-left">Odds</th>
                    </tr>
                  </thead>
                  <tbody>
                    {matchRows.map((row) => (
                      <tr
                        key={`${row.match}-${row.bookmaker}`}
                        className="border-b border-slate-800/70"
                      >
                        <td className="px-4 py-3 font-medium">{row.bookmaker}</td>
                        <td className="px-4 py-3">
                          <div className="flex flex-wrap gap-2">
                            {row.odds.map((odd) => {
                              const best = row.bestOutcomes.find(
                                (item) => item.outcome === odd.outcome
                              );
                              const isBest = best?.bookmaker === row.bookmaker;
                              return (
                                <span
                                  key={`${row.bookmaker}-${odd.outcome}`}
                                  className={`inline-flex items-center gap-2 rounded-full px-3 py-1 border ${
                                    isBest
                                      ? "border-emerald-500/70 bg-emerald-500/20 text-emerald-200"
                                      : "border-slate-700 bg-slate-900 text-slate-200"
                                  }`}
                                >
                                  <span className="text-xs text-slate-300">
                                    {odd.outcome}
                                  </span>
                                  <span className="font-mono">
                                    {odd.value.toFixed(2)}
                                  </span>
                                  {isBest && (
                                    <span className="text-[10px] uppercase tracking-wide">
                                      Best
                                    </span>
                                  )}
                                </span>
                              );
                            })}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </section>
          ))}
      </div>
    </main>
  );
}

export default App;

