import { OddsRow, OddsSource } from "../types";

const MOCK_ODDS: OddsRow[] = [
  {
    match: "Arrows FC vs Tigers FC",
    bookmaker: "BookieOne",
    odds: [
      { outcome: "Home", value: 2.2 },
      { outcome: "Draw", value: 3.25 },
      { outcome: "Away", value: 3.1 }
    ]
  },
  {
    match: "Arrows FC vs Tigers FC",
    bookmaker: "BookieTwo",
    odds: [
      { outcome: "Home", value: 2.15 },
      { outcome: "Draw", value: 3.35 },
      { outcome: "Away", value: 3.25 }
    ]
  },
  {
    match: "Arrows FC vs Tigers FC",
    bookmaker: "BookieThree",
    odds: [
      { outcome: "Home", value: 2.3 },
      { outcome: "Draw", value: 3.1 },
      { outcome: "Away", value: 3.0 }
    ]
  },
  {
    match: "Owls BC vs Lions BC",
    bookmaker: "BookieOne",
    odds: [
      { outcome: "Home", value: 1.9 },
      { outcome: "Away", value: 1.95 }
    ]
  },
  {
    match: "Owls BC vs Lions BC",
    bookmaker: "BookieTwo",
    odds: [
      { outcome: "Home", value: 2.02 },
      { outcome: "Away", value: 1.82 }
    ]
  },
  {
    match: "Owls BC vs Lions BC",
    bookmaker: "BookieThree",
    odds: [
      { outcome: "Home", value: 1.98 },
      { outcome: "Away", value: 1.9 }
    ]
  }
];

export function createMockSource(): OddsSource {
  return {
    name: "mock-data",
    async fetchOdds() {
      return MOCK_ODDS;
    }
  };
}
