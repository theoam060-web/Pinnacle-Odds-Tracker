const { spawn } = require("child_process");

function run(label, command, args) {
  const child = spawn(command, args, {
    stdio: "inherit",
    shell: true,
    env: process.env
  });

  child.on("exit", (code) => {
    if (code !== 0) {
      console.error(`${label} exited with code ${code}`);
      process.exit(code ?? 1);
    }
  });

  return child;
}

const backend = run("backend", "npm", ["run", "backend"]);
const frontend = run("frontend", "npm", ["run", "frontend"]);

function shutdown() {
  backend.kill();
  frontend.kill();
}

process.on("SIGINT", shutdown);
process.on("SIGTERM", shutdown);
