import express from "express";
import cors from "cors";
import { createOddsService } from "./services/oddsService";
import { createMockSource } from "./dataSources/mockSource";
import { createFreeApiSource } from "./dataSources/freeApiSource";

const app = express();
const port = Number(process.env.PORT || 4000);
const sourceMode = (process.env.ODDS_SOURCE || "mock").toLowerCase();

const source = sourceMode === "free-api" ? createFreeApiSource() : createMockSource();
const oddsService = createOddsService(source);

app.use(cors());
app.use(express.json());

app.get("/health", (_req, res) => {
  res.json({
    status: "ok",
    source: source.name
  });
});

app.get("/api/odds", async (_req, res) => {
  try {
    const rows = await oddsService.getAllOdds();
    res.json(rows);
  } catch (error) {
    res.status(500).json({ error: (error as Error).message });
  }
});

app.get("/api/odds/best", async (_req, res) => {
  try {
    const comparison = await oddsService.getComparison();
    res.json(comparison);
  } catch (error) {
    res.status(500).json({ error: (error as Error).message });
  }
});

app.listen(port, () => {
  console.log(`Odds API listening on http://localhost:${port}`);
  console.log(`Active source: ${source.name}`);
});

