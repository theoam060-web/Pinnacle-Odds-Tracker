import { ComparedOutcome, ComparedRow, OddsRow, OddsSource } from "../types";

type OddsService = {
  getAllOdds(): Promise<OddsRow[]>;
  getComparison(): Promise<ComparedRow[]>;
};

export function createOddsService(source: OddsSource): OddsService {
  async function getAllOdds(): Promise<OddsRow[]> {
    return source.fetchOdds();
  }

  async function getComparison(): Promise<ComparedRow[]> {
    const rows = await source.fetchOdds();
    const bestByMatchAndOutcome = new Map<string, ComparedOutcome>();

    for (const row of rows) {
      for (const odd of row.odds) {
        const key = `${row.match}::${odd.outcome}`;
        const currentBest = bestByMatchAndOutcome.get(key);
        if (!currentBest || odd.value > currentBest.value) {
          bestByMatchAndOutcome.set(key, {
            outcome: odd.outcome,
            value: odd.value,
            bookmaker: row.bookmaker
          });
        }
      }
    }

    return rows.map((row) => {
      const bestOutcomes = row.odds
        .map((odd) => bestByMatchAndOutcome.get(`${row.match}::${odd.outcome}`))
        .filter((item): item is ComparedOutcome => Boolean(item));
      return { ...row, bestOutcomes };
    });
  }

  return { getAllOdds, getComparison };
}
