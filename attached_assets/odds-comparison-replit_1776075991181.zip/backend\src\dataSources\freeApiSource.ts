import { OddsRow, OddsSource } from "../types";

type ApiBookmaker = {
  title: string;
  markets: Array<{
    outcomes: Array<{ name: string; price: number }>;
  }>;
};

type ApiEvent = {
  home_team: string;
  away_team: string;
  bookmakers: ApiBookmaker[];
};

export function createFreeApiSource(): OddsSource {
  return {
    name: "the-odds-api",
    async fetchOdds() {
      const apiKey = process.env.ODDS_API_KEY;
      if (!apiKey) {
        throw new Error(
          "ODDS_API_KEY is missing. Set it or use ODDS_SOURCE=mock."
        );
      }

      const url =
        "https://api.the-odds-api.com/v4/sports/soccer_epl/odds/" +
        `?apiKey=${apiKey}&regions=eu&markets=h2h`;
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error(`Odds API request failed with status ${response.status}`);
      }

      const payload = (await response.json()) as ApiEvent[];
      const rows: OddsRow[] = [];

      for (const event of payload) {
        const match = `${event.home_team} vs ${event.away_team}`;
        for (const bookmaker of event.bookmakers ?? []) {
          const firstMarket = bookmaker.markets?.[0];
          if (!firstMarket?.outcomes?.length) continue;

          rows.push({
            match,
            bookmaker: bookmaker.title,
            odds: firstMarket.outcomes.map((item) => ({
              outcome: item.name,
              value: Number(item.price)
            }))
          });
        }
      }

      return rows;
    }
  };
}
