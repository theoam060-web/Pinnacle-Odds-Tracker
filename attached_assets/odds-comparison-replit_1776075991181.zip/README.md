# Odds Comparison Prototype (School Project)

This project is a simple full-stack prototype that shows how odds comparison platforms work technically.

It includes:
- A Node.js backend API (TypeScript)
- A React frontend (Vite)
- A swappable backend data source layer (mock data now, API/scraper later)

## What It Does

- Fetches odds rows in a normalized format:
  - `match`
  - `bookmaker`
  - `odds` (outcome + value)
- Compares bookmakers for each match/outcome
- Highlights the best available odds in the frontend

## Project Structure

- `backend/src/index.ts` - API routes and source wiring
- `backend/src/services/oddsService.ts` - comparison logic
- `backend/src/dataSources/mockSource.ts` - mock odds source
- `backend/src/dataSources/freeApiSource.ts` - optional public API source
- `frontend/src/App.tsx` - odds table UI with best-odds highlighting
- `.replit` - Replit run config
- `scripts/dev-replit.js` - starts backend and frontend together

## Run In Replit (Recommended)

### 1) Import project
Create/import this repo in Replit (Node.js template is fine).

### 2) Install dependencies
Open the Replit shell and run:

```bash
npm install
```

### 3) Run the app
Click the **Run** button.

The `.replit` file is already configured to run:

```bash
npm run dev:replit
```

This starts:
- Backend at `http://localhost:4000`
- Frontend dev server at `http://localhost:5173`

The frontend proxies `/api` requests to the backend automatically.

## Environment Variables

By default, the app uses mock data:

- `ODDS_SOURCE=mock`

To switch to the optional public API source:

- `ODDS_SOURCE=free-api`
- `ODDS_API_KEY=<your_key>`

Set these in Replit **Secrets** (recommended), then restart Run.

## API Endpoints

- `GET /health` - API health + active source
- `GET /api/odds` - normalized odds rows
- `GET /api/odds/best` - rows plus best-odds comparison

## How To Swap Data Source Later

The backend is intentionally modular.

1. Add a new source file in `backend/src/dataSources/`, for example `scrapeSource.ts`
2. Implement `fetchOdds()` and return `OddsRow[]`
3. Wire it in `backend/src/index.ts` (choose source based on env var)

You do not need to change the comparison logic or frontend format.

## Troubleshooting

### `npm: command not found`
- Replit workspace is not using a Node environment.
- Fix: switch to Node.js template or ensure Node/NPM are installed.

### Frontend loads but table is empty
- Check backend is running and open `/health`.
- Confirm `ODDS_SOURCE` is set correctly.
- If using `free-api`, verify `ODDS_API_KEY` exists and is valid.

### API calls fail in browser console
- Ensure frontend dev server is running on Vite (port `5173`).
- Confirm `frontend/vite.config.ts` still has proxy entries for `/api` and `/health`.

### `ODDS_SOURCE=free-api` but still getting errors
- API key might be missing, expired, or rate-limited.
- Test with `ODDS_SOURCE=mock` first to verify app setup.

### Run button starts only one service
- Verify `.replit` contains:
  - `run = "npm run dev:replit"`
- Verify `scripts/dev-replit.js` exists.

## Notes For School Demo

- Keep `ODDS_SOURCE=mock` during presentations for stable output.
- Show source-switching as architecture flexibility.
- Explain that real scraping/API integration can be plugged into the same interface.
